/**
 * transition.js – chuyển trang kiểu District2
 * Animation overlay bằng GSAP
 */

const pageCache = new Map();
const DURATION = 0.35;

function getOverlay() {
  return document.getElementById("location-transition");
}

function fadeIn(color) {
  return new Promise((resolve) => {
    const overlay = getOverlay();
    gsap.set(overlay, {
      zIndex: 99,
      visibility: "visible",
      backgroundColor: color || "#f7f7f7",
      opacity: 0,
    });
    gsap.to(overlay, {
      opacity: 1,
      duration: DURATION,
      ease: "power2.out",
      onComplete: resolve,
    });
  });
}

function fadeOut() {
  return new Promise((resolve) => {
    const overlay = getOverlay();
    gsap.to(overlay, {
      opacity: 0,
      duration: DURATION,
      ease: "power2.in",
      onComplete: () => {
        gsap.set(overlay, { visibility: "hidden", zIndex: -1 });
        resolve();
      },
    });
  });
}

function getOverlayColor(path) {
  const clean = (path || "").split("#")[0];
  if (!clean || clean === "/" || clean.endsWith("index.html")) return "#ffffff";
  if (clean.includes("about")) return "#f7f7f7";
  if (clean.includes("work")) return "#f0f0f0";
  if (clean.includes("contact")) return "#e8e8e8";
  return "#f7f7f7";
}

function parseUrl(url) {
  try {
    const u = new URL(url, location.origin);
    return {
      path: u.pathname.split("/").pop() || "index.html",
      hash: u.hash || null,
      href: u.pathname + u.search + u.hash,
    };
  } catch {
    const [pathPart, hashPart] = (url || "").split("#");
    return {
      path: pathPart.split("/").pop() || "index.html",
      hash: hashPart ? "#" + hashPart : null,
      href: url,
    };
  }
}

function parsePage(html) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  return {
    title: doc.querySelector("title")?.textContent || document.title,
    bodyClass: doc.body.className || "home",
    content: doc.querySelector("#content-page")?.innerHTML || "",
  };
}

async function fetchPage(url) {
  const { path } = parseUrl(url);
  if (pageCache.has(path)) return pageCache.get(path);

  const res = await fetch(path, {
    headers: { "X-Requested-With": "XMLHttpRequest" },
  });
  if (!res.ok) throw new Error("Fetch failed: " + path);
  const html = await res.text();
  const data = parsePage(html);
  pageCache.set(path, data);
  return data;
}

function bindLinks(root = document) {
  root.querySelectorAll("a.location__href").forEach((a) => {
    if (a.dataset.bound) return;
    a.dataset.bound = "1";
    a.addEventListener("click", handleLinkClick);
  });
}

function updatePage({ title, bodyClass, content }, url, isPopstate = false) {
  document.title = title;
  document.body.className = bodyClass;

  const contentEl = document.getElementById("content-page");
  contentEl.innerHTML = content;
  bindLinks(contentEl);

  const { href, hash } = parseUrl(url);
  if (!isPopstate) {
    history.pushState({ url: href }, title, href);
  }

  // Hook từ app.js
  if (typeof window.onPageReady === "function") {
    window.onPageReady(hash);
  }
}

async function handleLinkClick(e) {
  const link = e.currentTarget;
  const href = link.getAttribute("href");

  if (!href || link.target === "_blank") return;
  if (href.startsWith("http") && !href.includes(location.host)) return;

  if (href.startsWith("#")) {
    e.preventDefault();
    if (typeof window.scrollToHash === "function") {
      window.scrollToHash(href);
    } else {
      document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
    }
    history.pushState(null, "", href);
    return;
  }

  e.preventDefault();

  const parsed = parseUrl(href);
  const currentPath = parseUrl(location.href).path;

  if (parsed.path === currentPath && parsed.hash) {
    if (typeof window.scrollToHash === "function") {
      window.scrollToHash(parsed.hash);
    } else {
      document.querySelector(parsed.hash)?.scrollIntoView({ behavior: "smooth" });
    }
    history.pushState({ url: parsed.href }, document.title, parsed.href);
    return;
  }

  try {
    if (typeof window.beforePageLeave === "function") {
      window.beforePageLeave();
    }
    await fadeIn(getOverlayColor(href));
    const data = await fetchPage(href);
    updatePage(data, href);
    await fadeOut();
  } catch (err) {
    console.error(err);
    await fadeOut();
    alert("Không thể tải trang. Thử lại nhé.");
  }
}

async function handlePopState(e) {
  const url = e.state?.url || location.href;
  try {
    if (typeof window.beforePageLeave === "function") {
      window.beforePageLeave();
    }
    await fadeIn(getOverlayColor(url));
    const data = await fetchPage(url);
    updatePage(data, url, true);
    await fadeOut();
  } catch (err) {
    console.error(err);
    await fadeOut();
  }
}

export function initTransition() {
  if (!document.getElementById("location-transition")) {
    const div = document.createElement("div");
    div.id = "location-transition";
    document.body.prepend(div);
  }

  gsap.set(getOverlay(), { opacity: 0, visibility: "hidden", zIndex: -1 });

  bindLinks(document);

  const initial = parseUrl(location.href);
  history.replaceState({ url: initial.href }, document.title, location.href);

  window.addEventListener("popstate", handlePopState);

  if (typeof window.onPageReady === "function") {
    window.onPageReady(initial.hash);
  }
}

export { bindLinks };
