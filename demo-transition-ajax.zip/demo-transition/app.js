/**
 * app.js – Lenis, toggle class, và các function init của trang
 * Transition logic nằm ở js/transition.js
 */

(function () {
  "use strict";

  // ===== Lenis (nếu có load thư viện) =====
  let lenis = null;

  function initLenis() {
    if (typeof Lenis === "undefined") {
      lenis = null;
      return;
    }
    if (lenis) {
      lenis.destroy();
      lenis = null;
    }
    lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    });
    function raf(time) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);
  }

  // ===== Các function toggle / init component =====
  function initPageScripts() {
    // Ví dụ toggle class
    document.querySelectorAll("[data-toggle]").forEach((el) => {
      if (el.dataset.bound) return;
      el.dataset.bound = "1";
      el.addEventListener("click", () => {
        const target = el.getAttribute("data-toggle");
        document.querySelector(target)?.classList.toggle("is-active");
      });
    });

    // Thêm function khác của bạn vào đây:
    // initAccordion();
    // initMenu();
    // initHoverEffects();
  }

  // ===== Scroll tới hash (Lenis hoặc native) =====
  function scrollToHash(hash) {
    const el = document.querySelector(hash);
    if (!el) return;
    if (lenis) {
      lenis.scrollTo(el, { offset: -80, duration: 1.2 });
    } else {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  // ===== Hook được transition.js gọi =====

  // Trước khi rời trang (stop Lenis…)
  window.beforePageLeave = function () {
    if (lenis) lenis.stop();
  };

  // Sau khi content mới sẵn sàng
  window.onPageReady = function (hash) {
    initLenis();
    initPageScripts();

    if (hash) {
      requestAnimationFrame(() => scrollToHash(hash));
    } else {
      if (lenis) {
        lenis.scrollTo(0, { immediate: true });
      } else {
        window.scrollTo(0, 0);
      }
    }

    document.dispatchEvent(new CustomEvent("apiPageReady", { detail: { hash } }));
  };

  // Cho transition.js dùng khi click pure hash
  window.scrollToHash = scrollToHash;

  // ===== Khởi chạy =====
  function start() {
    if (typeof window.initTransition === "function") {
      window.initTransition();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
