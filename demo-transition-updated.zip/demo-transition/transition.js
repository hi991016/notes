/* -------------------------------------------------------
   Page Transitions — Barba.js + GSAP
   Adapted from codebydennis.com style
------------------------------------------------------- */

gsap.registerPlugin(CustomEase);
CustomEase.create("animation-nav", ".3, 0, .3, 1");

const transitionOffset = 450;

// ── Pending hash scroll (cross-page anchor nav) ──────────
let pendingHash = null;

// ── Helpers ──────────────────────────────────────────────
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms || 2000));
}

function smoothScrollTo(hash) {
  const el = document.getElementById(hash);
  if (!el) return;
  const navH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nav-h')) || 72;
  const top = el.getBoundingClientRect().top + window.scrollY - navH;
  window.scrollTo({ top, behavior: 'smooth' });
}

function isHomePage() {
  const p = window.location.pathname;
  return p === '/' || p.endsWith('/index.html') || p.endsWith('/');
}

// ── Hash-anchor click handler (capture phase, before Barba) ──
// Handles links like /#fv, index.html#fv, /index.html#fv
document.addEventListener('click', function (e) {
  const link = e.target.closest('a[href]');
  if (!link) return;

  const href = link.getAttribute('href');
  if (!href || !href.includes('#')) return;

  const hashIdx = href.indexOf('#');
  const pathPart = href.slice(0, hashIdx);   // e.g. "/" or "index.html" or ""
  const hash     = href.slice(hashIdx + 1);  // e.g. "fv"
  if (!hash) return;

  // Only handle links that point to the home page
  const isHomeLink =
    pathPart === '' ||
    pathPart === '/' ||
    pathPart === 'index.html' ||
    pathPart === '/index.html' ||
    pathPart === './index.html';
  if (!isHomeLink) return;

  // Always take over — prevent browser default & Barba
  e.preventDefault();
  e.stopImmediatePropagation();

  if (isHomePage()) {
    // Already on home → just scroll
    smoothScrollTo(hash);
  } else {
    // On another page → store hash, navigate home via Barba (no hash in URL)
    pendingHash = hash;
    barba.go(pathPart || '/');
  }
}, true); // ← capture phase so we fire before Barba's bubble-phase listener


// ── Page Leave: overlay flashes in + circle spins ────────
function pageTransitionIn() {
  const tl = gsap.timeline();
  const circle = document.querySelector(".loading-circle svg circle");
  const circleLength = circle ? circle.getTotalLength() : 100;

  tl.set("html", { cursor: "wait" });

  tl.to(".transition-screen", { duration: 0.4, autoAlpha: 1, ease: "animation-nav" }, 0);
  tl.to(".transition-screen", { duration: 0.8, autoAlpha: 0, ease: "animation-nav" }, 0.5)
    .set("html", { cursor: "auto" }, "=-0.5");

  tl.set(".loading-circle svg circle",
    { strokeDashoffset: circleLength * 3, strokeDasharray: circleLength + 2, opacity: 1 }, 0);
  tl.set(".loading-circle svg", { rotate: 0, opacity: 1 }, 0);

  tl.to(".loading-circle svg", { rotate: 360, duration: 1.3, ease: "none" }, 0);
  tl.to(".loading-circle svg circle",
    { autoAlpha: 1, duration: 0.65, ease: "Power1.easeIn", strokeDashoffset: circleLength * 2 }, 0);
  tl.to(".loading-circle svg circle",
    { autoAlpha: 1, duration: 0.65, ease: "Power1.easeOut", strokeDashoffset: circleLength * 1 }, 0.7);
  tl.to(".loading-circle svg", { duration: 0.01, opacity: 0 }, 1.25);

  tl.call(() => {
    document.querySelector("[data-page-transition]")
      ?.setAttribute("data-page-transition", "active");
  }, null, 0);
  tl.call(() => {
    document.querySelector("[data-page-transition]")
      ?.setAttribute("data-page-transition", "not-active");
  }, null, 0.5);

  return tl;
}

// ── Page Enter: content blurs/slides in ──────────────────
function pageTransitionOut() {
  const tl = gsap.timeline();
  const targets = ".page-header .col-row, .page-header + .section";

  tl.set(targets, { rotate: 0.001, opacity: 0, y: "1em", filter: "blur(0.25em)", scale: 0.975 }, 0);
  tl.to(targets, { duration: 1.4, rotate: 0.001, opacity: 1, y: "0em", ease: "expo.out", stagger: 0.1, scale: 1 }, 0.2);
  tl.to(targets, { duration: 2, ease: "expo.out", clearProps: "all", stagger: 0.1, filter: "blur(0em)", scale: 1 }, 0.2);

  return tl;
}

// ── Active Nav Link ──────────────────────────────────────
function updateActiveNav() {
  const currentPath = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a").forEach((link) => {
    const href = link.getAttribute("href");
    // Skip hash-only links from active state logic
    if (href && href.includes('#')) return;
    link.classList.toggle("nav-active", href === currentPath);
  });
}

// ── Barba Init ───────────────────────────────────────────
barba.init({
  sync: true,
  debug: false,
  timeout: 7000,

  transitions: [
    {
      name: "default",

      // First load — no loading screen, just reveal content
      once() {
        updateActiveNav();
        pageTransitionOut();

        // Handle direct URL load with hash (e.g. user opens index.html#fv directly)
        if (window.location.hash) {
          const hash = window.location.hash.slice(1);
          setTimeout(() => smoothScrollTo(hash), 800);
        }
      },

      // Link clicked → leave current page
      async leave() {
        pageTransitionIn();
        await delay(transitionOffset);
      },

      // New page DOM ready → reveal content
      async enter() {
        window.scrollTo(0, 0);
        updateActiveNav();
        pageTransitionOut();

        // If a hash-anchor nav triggered this transition, scroll after reveal starts
        if (pendingHash) {
          const hash = pendingHash;
          pendingHash = null;
          await delay(600); // let the page reveal animation start first
          smoothScrollTo(hash);
        }
      },
    },
  ],
});
