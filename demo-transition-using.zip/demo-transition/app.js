/**
 * app.js – Lenis + toggle class + init scripts
 * Script thường, ES6 syntax (không type=module, không IIFE)
 */

let lenis = null;

const initLenis = () => {
  if (typeof Lenis === "undefined") {
    lenis = null;
    return;
  }
  if (lenis) {
    lenis.destroy();
    lenis = null;
  }

  lenis = new Lenis({
    duration: 1.2,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smoothWheel: true,
  });

  const raf = (time) => {
    lenis.raf(time);
    requestAnimationFrame(raf);
  };
  requestAnimationFrame(raf);
};

const initPageScripts = () => {
  // Ví dụ toggle class
  document.querySelectorAll("[data-toggle]").forEach((el) => {
    if (el.dataset.bound) return;
    el.dataset.bound = "1";
    el.addEventListener("click", () => {
      const target = el.getAttribute("data-toggle");
      document.querySelector(target)?.classList.toggle("is-active");
    });
  });

  // Thêm function khác của bạn vào đây:
  // initAccordion();
  // initMenu();
  // initHoverEffects();
};

const scrollToHash = (hash) => {
  const el = document.querySelector(hash);
  if (!el) return;
  if (lenis) {
    lenis.scrollTo(el, { offset: -80, duration: 1.2 });
  } else {
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
};

// Hook cho transition.js
window.beforePageLeave = () => {
  if (lenis) lenis.stop();
};

window.onPageReady = (hash) => {
  initLenis();
  initPageScripts();

  if (hash) {
    requestAnimationFrame(() => scrollToHash(hash));
  } else if (lenis) {
    lenis.scrollTo(0, { immediate: true });
  } else {
    window.scrollTo(0, 0);
  }

  document.dispatchEvent(new CustomEvent("apiPageReady", { detail: { hash } }));
};

window.scrollToHash = scrollToHash;

// Start (transition.js đã load trước)
window.initTransition();
