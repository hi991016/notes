# WordPress Page Transition (District2 style)

Chuyển trang mượt bằng AJAX + GSAP overlay, có sẵn:

- Endpoint `load_page_html` (giống mẫu)
- Lenis smooth scroll
- **Contact Form 7** re-init
- **gtag / GA / GTM** virtual pageview
- `DONOTCACHEPAGE` + `nocache_headers` cho AJAX

## Cài đặt

### 1. Copy file vào theme

```
your-theme/
├── js/
│   ├── transition.js
│   └── app.js
├── css/
│   └── transition.css          (hoặc gộp vào style theme)
└── inc/
    └── ajax-page-transition.php
```

### 2. functions.php

```php
require get_template_directory() . '/inc/ajax-page-transition.php';
add_action('wp_enqueue_scripts', 'd2_enqueue_page_transition_assets');

// CSS overlay
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'd2-transition',
        get_template_directory_uri() . '/css/transition.css',
        [],
        '1.0.0'
    );
});
```

### 3. Layout theme

- Bọc nội dung đổi được trong `#content-page`
- Thêm overlay:

```html
<div id="location-transition"></div>
<main id="content-page">
  <?php /* nội dung trang */ ?>
</main>
```

- Link nội bộ thêm class `location__href`:

```html
<a href="<?php echo esc_url(home_url('/about/')); ?>" class="location__href">About</a>
```

Menu WP: filter `nav_menu_link_attributes` để gắn class, hoặc hardcode.

### 4. CF7

Form trong page content (shortcode) → sau transition, `app.js` gọi `wpcf7.init(form)`.

Đảm bảo CF7 script vẫn enqueue global (không dequeue).

### 5. gtag

Giữ snippet gtag/GTM như bình thường. Mỗi lần AJAX xong, `trackPageView()` bắn:

- `gtag('event', 'page_view', …)`
- `dataLayer.push({ event: 'virtualPageview', … })`

Lần load đầu không bắn trùng (chỉ khi `pageData` từ AJAX).

### 6. Cache

AJAX đã:

- `DONOTCACHEPAGE`
- `nocache_headers()`
- `Cache-Control: no-store`

Với **WP Super Cache / LiteSpeed / Cloudflare**:

- Exclude URL chứa `admin-ajax.php` + `action=load_page_html`
- Hoặc rule: query string `action=load_page_html` → bypass cache

HTML trang thật (F5, bot) vẫn cache bình thường.

## API response (tham khảo District2)

```json
{
  "documentTitle": "About – Site",
  "pageHtml": "<article>...</article>",
  "bodyClass": "page page-id-12 ...",
  "postType": "page",
  "slug": "about"
}
```

## Mở rộng

- Project CPT: chỉnh `get_page_by_path(..., ['project'])` trong PHP
- Multilingual: truyền `lang` thêm query, filter slug trong handler
- Thêm init: viết trong `initPageScripts()` ở `app.js`

## Lưu ý

- Vào thẳng URL / share link vẫn phải render full page (theme bình thường)
- Transition chỉ enhance – progressive enhancement
- Test CF7, analytics, Back/Forward trên staging trước khi lên production
