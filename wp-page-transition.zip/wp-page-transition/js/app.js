/**
 * app.js – Lenis, CF7, gtag, toggle class
 * Gọi lại sau mỗi lần chuyển trang trong onPageReady
 */

let lenis = null;

const initLenis = () => {
  if (typeof Lenis === "undefined") {
    lenis = null;
    return;
  }
  if (lenis) {
    lenis.destroy();
    lenis = null;
  }
  lenis = new Lenis({
    duration: 1.2,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smoothWheel: true,
  });
  const raf = (time) => {
    lenis.raf(time);
    requestAnimationFrame(raf);
  };
  requestAnimationFrame(raf);
};

/** Contact Form 7 – re-init sau AJAX */
const initCF7 = () => {
  if (typeof wpcf7 === "undefined") return;

  document.querySelectorAll(".wpcf7 > form").forEach((form) => {
    try {
      // CF7 5.4+
      if (typeof wpcf7.init === "function") {
        wpcf7.init(form);
      } else if (typeof wpcf7.initForm === "function") {
        wpcf7.initForm(form);
      }
    } catch (e) {
      console.warn("CF7 re-init:", e);
    }
  });
};

/** Google Analytics (gtag) – pageview mỗi lần đổi trang */
const trackPageView = () => {
  const path = location.pathname + location.search + location.hash;

  // gtag (GA4 / Universal)
  if (typeof gtag === "function") {
    gtag("event", "page_view", {
      page_path: path,
      page_title: document.title,
      page_location: location.href,
    });
  }

  // GA Universal (ga)
  if (typeof ga === "function") {
    ga("set", "page", path);
    ga("send", "pageview");
  }

  // dataLayer (GTM)
  if (window.dataLayer && Array.isArray(window.dataLayer)) {
    window.dataLayer.push({
      event: "virtualPageview",
      pagePath: path,
      pageTitle: document.title,
    });
  }
};

const initPageScripts = () => {
  // Toggle class demo
  document.querySelectorAll("[data-toggle]").forEach((el) => {
    if (el.dataset.bound) return;
    el.dataset.bound = "1";
    el.addEventListener("click", () => {
      const target = el.getAttribute("data-toggle");
      document.querySelector(target)?.classList.toggle("is-active");
    });
  });

  // CF7
  initCF7();

  // Thêm init khác:
  // initAccordion();
  // initMenu();
};

const scrollToHash = (hash) => {
  const el = document.querySelector(hash);
  if (!el) return;
  if (lenis) {
    lenis.scrollTo(el, { offset: -80, duration: 1.2 });
  } else {
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
};

window.beforePageLeave = () => {
  if (lenis) lenis.stop();
};

/**
 * @param {string|null} hash
 * @param {object|null} pageData - data từ AJAX (lần đầu load có thể null)
 */
window.onPageReady = (hash, pageData) => {
  initLenis();
  initPageScripts();

  if (hash) {
    requestAnimationFrame(() => scrollToHash(hash));
  } else if (lenis) {
    lenis.scrollTo(0, { immediate: true });
  } else {
    window.scrollTo(0, 0);
  }

  // Không track lần đầu (đã có pageview mặc định) – chỉ track khi có pageData từ AJAX
  if (pageData) {
    trackPageView();
  }

  document.dispatchEvent(
    new CustomEvent("apiPageReady", { detail: { hash, pageData } })
  );
};

window.scrollToHash = scrollToHash;

// Start
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => window.initTransition());
} else {
  window.initTransition();
}
