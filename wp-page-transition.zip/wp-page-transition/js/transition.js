/**
 * transition.js – WordPress page transition (District2 style)
 * Cần: GSAP, wpData.ajaxUrl (wp_localize_script)
 */

const pageCache = new Map();
const DURATION = 0.35;

const getOverlay = () => document.getElementById("location-transition");

const fadeIn = (color) =>
  new Promise((resolve) => {
    const overlay = getOverlay();
    if (!overlay || typeof gsap === "undefined") {
      resolve();
      return;
    }
    gsap.set(overlay, {
      zIndex: 99,
      visibility: "visible",
      backgroundColor: color || "#f7f7f7",
      opacity: 0,
    });
    gsap.to(overlay, {
      opacity: 1,
      duration: DURATION,
      ease: "power2.out",
      onComplete: resolve,
    });
  });

const fadeOut = () =>
  new Promise((resolve) => {
    const overlay = getOverlay();
    if (!overlay || typeof gsap === "undefined") {
      resolve();
      return;
    }
    gsap.to(overlay, {
      opacity: 0,
      duration: DURATION,
      ease: "power2.in",
      onComplete: () => {
        gsap.set(overlay, { visibility: "hidden", zIndex: -1 });
        resolve();
      },
    });
  });

const getOverlayColor = (path) => {
  const clean = (path || "").split("#")[0];
  if (!clean || clean === "/" || clean === "home") return "#ffffff";
  if (clean.includes("about")) return "#f7f7f7";
  if (clean.includes("work") || clean.includes("project")) return "#f0f0f0";
  if (clean.includes("contact")) return "#e8e8e8";
  return "#f7f7f7";
};

/** Lấy slug từ URL (bỏ domain, home path) */
const getSlugFromUrl = (url) => {
  try {
    const u = new URL(url, location.origin);
    let path = u.pathname.replace(/\/+$/, "") || "/";
    const home = (window.wpData && wpData.homeUrl) || location.origin + "/";
    const homePath = new URL(home).pathname.replace(/\/+$/, "") || "";
    if (homePath && path.startsWith(homePath)) {
      path = path.slice(homePath.length) || "/";
    }
    path = path.replace(/^\/+/, "");
    return {
      slug: path === "" ? "home" : path,
      hash: u.hash || null,
      href: u.pathname + u.search + u.hash,
    };
  } catch {
    return { slug: "home", hash: null, href: url };
  }
};

const fetchPageBySlug = async (slug) => {
  const key = slug || "home";
  if (pageCache.has(key)) return pageCache.get(key);

  const ajaxUrl = (window.wpData && wpData.ajaxUrl) || "/wp-admin/admin-ajax.php";
  const action = (window.wpData && wpData.action) || "load_page_html";
  const url = `${ajaxUrl}?action=${encodeURIComponent(action)}&slug=${encodeURIComponent(key)}`;

  const res = await fetch(url, {
    headers: { "X-Requested-With": "XMLHttpRequest" },
    credentials: "same-origin",
  });
  if (!res.ok) throw new Error("Fetch failed: " + key);
  const data = await res.json();
  pageCache.set(key, data);
  return data;
};

const bindLinks = (root = document) => {
  root.querySelectorAll("a.location__href").forEach((a) => {
    if (a.dataset.bound) return;
    a.dataset.bound = "1";
    a.addEventListener("click", handleLinkClick);
  });
};

const updatePage = (data, url, isPopstate = false) => {
  document.title = data.documentTitle || document.title;
  if (data.bodyClass) {
    document.body.className = data.bodyClass;
  }

  const contentEl = document.getElementById("content-page");
  if (contentEl && data.pageHtml != null) {
    contentEl.innerHTML = data.pageHtml;
    bindLinks(contentEl);
  }

  const { href, hash, slug } = getSlugFromUrl(url);
  if (!isPopstate) {
    history.pushState({ url: href, slug }, data.documentTitle || "", href);
  }

  if (typeof window.onPageReady === "function") {
    window.onPageReady(hash, data);
  }
};

const handleLinkClick = async (e) => {
  const link = e.currentTarget;
  const href = link.getAttribute("href");

  if (!href || link.target === "_blank") return;
  if (href.startsWith("mailto:") || href.startsWith("tel:")) return;
  if (href.startsWith("http") && !href.includes(location.host)) return;

  // Pure hash
  if (href.startsWith("#")) {
    e.preventDefault();
    if (typeof window.scrollToHash === "function") {
      window.scrollToHash(href);
    } else {
      document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
    }
    history.pushState(null, "", href);
    return;
  }

  e.preventDefault();

  const parsed = getSlugFromUrl(href);
  const current = getSlugFromUrl(location.href);

  // Cùng trang + hash
  if (parsed.slug === current.slug && parsed.hash) {
    if (typeof window.scrollToHash === "function") {
      window.scrollToHash(parsed.hash);
    } else {
      document.querySelector(parsed.hash)?.scrollIntoView({ behavior: "smooth" });
    }
    history.pushState({ url: parsed.href, slug: parsed.slug }, document.title, parsed.href);
    return;
  }

  try {
    if (typeof window.beforePageLeave === "function") {
      window.beforePageLeave();
    }
    await fadeIn(getOverlayColor(parsed.slug));
    const data = await fetchPageBySlug(parsed.slug);
    updatePage(data, href);
    await fadeOut();
  } catch (err) {
    console.error(err);
    await fadeOut();
    // Fallback: full reload
    location.href = href;
  }
};

const handlePopState = async (e) => {
  const url = (e.state && e.state.url) || location.href;
  const { slug } = getSlugFromUrl(url);
  try {
    if (typeof window.beforePageLeave === "function") {
      window.beforePageLeave();
    }
    await fadeIn(getOverlayColor(slug));
    const data = await fetchPageBySlug(slug);
    updatePage(data, url, true);
    await fadeOut();
  } catch (err) {
    console.error(err);
    await fadeOut();
    location.reload();
  }
};

const initTransition = () => {
  if (!document.getElementById("location-transition")) {
    const div = document.createElement("div");
    div.id = "location-transition";
    document.body.prepend(div);
  }

  if (typeof gsap !== "undefined") {
    gsap.set(getOverlay(), { opacity: 0, visibility: "hidden", zIndex: -1 });
  }

  bindLinks(document);

  const initial = getSlugFromUrl(location.href);
  history.replaceState(
    { url: initial.href, slug: initial.slug },
    document.title,
    location.href
  );

  window.addEventListener("popstate", handlePopState);

  if (typeof window.onPageReady === "function") {
    window.onPageReady(initial.hash, null);
  }
};

window.initTransition = initTransition;
window.bindLocationLinks = bindLinks;
