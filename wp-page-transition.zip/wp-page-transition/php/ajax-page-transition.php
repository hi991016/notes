<?php
/**
 * Page Transition AJAX – tham khảo district2.studio
 *
 * Cách dùng: require trong functions.php
 * require get_template_directory() . '/inc/ajax-page-transition.php';
 *
 * Action: load_page_html
 * Request: admin-ajax.php?action=load_page_html&slug=about
 *          (slug = path relative, có thể kèm lang: en/about)
 *
 * Response JSON:
 * {
 *   "documentTitle": "...",
 *   "pageHtml": "<div>...</div>",  // nội dung #content-page
 *   "bodyClass": "page page-about ...",
 *   "postType": "page",
 *   "slug": "about"
 * }
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Không cache response AJAX (tránh Super Cache / Cloudflare cache nhầm)
 */
add_action('init', function () {
    if (!defined('DOING_AJAX') || !DOING_AJAX) {
        return;
    }
    if (empty($_REQUEST['action']) || $_REQUEST['action'] !== 'load_page_html') {
        return;
    }
    if (!defined('DONOTCACHEPAGE')) {
        define('DONOTCACHEPAGE', true);
    }
    nocache_headers();
});

/**
 * AJAX handler (logged-in + guest)
 */
add_action('wp_ajax_load_page_html', 'd2_load_page_html');
add_action('wp_ajax_nopriv_load_page_html', 'd2_load_page_html');

function d2_load_page_html() {
    // Không cache
    nocache_headers();
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');

    $slug = isset($_GET['slug']) ? sanitize_text_field(wp_unslash($_GET['slug'])) : '';
    $slug = trim($slug, '/');

    // Home
    if ($slug === '' || $slug === 'home' || $slug === 'index') {
        $post = get_post((int) get_option('page_on_front'));
        if (!$post) {
            // Fallback: blog index – trả HTML đơn giản
            wp_send_json([
                'documentTitle' => wp_get_document_title(),
                'pageHtml'      => d2_render_fallback_home(),
                'bodyClass'     => 'home',
                'postType'      => 'page',
                'slug'          => 'home',
            ]);
        }
    } else {
        // Thử page theo path
        $post = get_page_by_path($slug, OBJECT, ['page', 'post']);

        // Custom post type project (giống D2) – chỉnh post_type nếu cần
        if (!$post) {
            $post = get_page_by_path($slug, OBJECT, ['project', 'd2_project']);
        }

        // Thử query theo name
        if (!$post) {
            $q = new WP_Query([
                'name'           => basename($slug),
                'post_type'      => ['page', 'post', 'project'],
                'post_status'    => 'publish',
                'posts_per_page' => 1,
            ]);
            if ($q->have_posts()) {
                $post = $q->posts[0];
            }
            wp_reset_postdata();
        }
    }

    if (!$post) {
        status_header(404);
        wp_send_json([
            'documentTitle' => 'Page not found',
            'pageHtml'      => '<div class="page-not-found"><h1>404</h1><p>Page not found.</p></div>',
            'bodyClass'     => 'error404',
            'postType'      => '',
            'slug'          => $slug,
        ]);
    }

    // Setup post data để template tags hoạt động
    global $wp_query, $post;
    // $post already holds the target post from above
    setup_postdata($post);

    // body class
    $body_class = implode(' ', get_body_class('', $post->ID));

    // Render partial – ưu tiên template riêng
    $html = d2_render_page_content($post);

    $title = get_the_title($post);
    if (function_exists('wp_get_document_title')) {
        // Tạm set queried object để title đúng
        $wp_query->queried_object = $post;
        $wp_query->queried_object_id = $post->ID;
        $wp_query->is_page = ($post->post_type === 'page');
        $wp_query->is_singular = true;
        $doc_title = wp_get_document_title();
    } else {
        $doc_title = $title . ' – ' . get_bloginfo('name');
    }

    wp_reset_postdata();

    wp_send_json([
        'documentTitle' => $doc_title,
        'pageHtml'      => $html,
        'bodyClass'     => $body_class,
        'postType'      => $post->post_type,
        'slug'          => $slug,
    ]);
}

/**
 * Render nội dung đưa vào #content-page (the_content + shortcode CF7 v.v.)
 */
function d2_render_page_content($post) {
    ob_start();
    echo '<article id="post-' . esc_attr($post->ID) . '" class="' . esc_attr(implode(' ', get_post_class('', $post->ID))) . '">';
    echo '<div class="entry-content">';
    echo apply_filters('the_content', $post->post_content);
    echo '</div></article>';
    return ob_get_clean();
}

function d2_render_fallback_home() {
    ob_start();
    echo '<div class="home-fallback"><h1>' . esc_html(get_bloginfo('name')) . '</h1></div>';
    return ob_get_clean();
}

/**
 * Localize wpData (giống district2)
 * Gọi trong wp_enqueue_scripts của theme
 */
function d2_enqueue_page_transition_assets() {
    $ver = '1.0.0';

    // GSAP + Lenis (CDN) – hoặc bundle local
    wp_enqueue_script('gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js', [], '3.12.5', true);
    wp_enqueue_script('lenis', 'https://cdn.jsdelivr.net/npm/lenis@1.1.18/dist/lenis.min.js', [], '1.1.18', true);

    wp_enqueue_script(
        'd2-transition',
        get_template_directory_uri() . '/js/transition.js',
        ['gsap'],
        $ver,
        true
    );
    wp_enqueue_script(
        'd2-app',
        get_template_directory_uri() . '/js/app.js',
        ['d2-transition', 'lenis'],
        $ver,
        true
    );

    wp_localize_script('d2-transition', 'wpData', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'homeUrl' => home_url('/'),
        'action'  => 'load_page_html',
    ]);
}
// add_action('wp_enqueue_scripts', 'd2_enqueue_page_transition_assets');
